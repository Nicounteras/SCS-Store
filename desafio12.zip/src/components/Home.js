import React, { useState, useEffect } from "react";
import ItemList from "./ItemScreen/ItemList"
import LoadingContainer from "./Loading/LoadingContainer";
import {getFirestore} from "../firebase"


export default function Home() {
  const [products, setProducts] = useState([])


  useEffect(() => {
    const db = getFirestore();
    const ItemCollection = db.collection("json-oficial")
    const AvailableItems = ItemCollection.where("available", "==", true);
    // const idItem = itemCollection.doc("nqYxwipNG16h9ScPXBvo");
 // Pedimos los datos
 AvailableItems.get().then((response) => {
  // console.log(response.data())
 const ProductDatabase = response.docs.map(element => {
  return element.data();
 });
  
 // Guardamos los datos en estado
 setProducts(ProductDatabase);
 console.log(products)
  
 });
  },[])
 
 

  return (
    <div>
     {/*  <h1>Mi tienda</h1>
     
      <ItemCount min = {1} max={20} initial={1} onAdd={addToCart}/> */}

      
       {
  products.length === 0 ? (
    <LoadingContainer/>
  ) : (
     <ItemList products={products}/>
  )
} 



    </div>
    
  );
}
