import './App.css';
import React, {useEffect, useState} from "react"
import NavBar from "./components/NavBar"
import Home from "./components/Home"
import ItemDetailContainer from "./components/ItemScreen/ItemDetailContainer"
import { BrowserRouter as Router, Switch, Route } from "react-router-dom"
import {AppProvider} from './Context/useAppContext';
import Cart from "./components/Cart/Cart"

function App() {
  return (
   <>
  <AppProvider>
  <Router>
   <NavBar/>
    <Switch>
      <Route path="/productos/:category/:id" component={ItemDetailContainer}/>
      <Route path="/" exact component={Home}/>
      <Route path="/carrito" exact component={Cart}/>
      </Switch> 
      </Router>
  </AppProvider>
   </>
  );
}


export default App;
