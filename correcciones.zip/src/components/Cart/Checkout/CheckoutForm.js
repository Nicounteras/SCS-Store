import validate from "./validate"
import useForm from "./useForm"


const CheckoutForm = () => {
    const {
        values,
        errors,
        handleChange,
        handleSubmit,
      } = useForm(checked, validate);

      function checked() {
        console.log('No errors, submit callback called!');
      }
   return (
    <form onSubmit={handleSubmit} noValidate>
        <p>Para poder realizar la compra, te pedimos rellenar este formulario.</p>
 <div className="container">
 <li>
    <label>Tu nombre</label>
        <input placeholder="Escribe tu nombre aquí" autoComplete="off" type="name" name="name" onChange={handleChange} value={values.name || ''} required/>
    </li>
    <li>
        <label>Tu correo electrónico</label>
        <input placeholder="Coloca tu e-mail aquí" autoComplete="off" type="email" name="email" onChange={handleChange} value={values.email || ''} required/>
        {errors.email && (
                    <span>{errors.email}</span>
                  )}

    </li>
    <li>
        <label>Tu número telefónico</label>
    <div className="telephone-area">
        <code>+51 🇵🇪</code>
    <input type="text" autoComplete="off" name="telephone" defaultValue="+51" onChange={handleChange} value={values.telephone || ''} required placeholder="Coloca tu número de teléfono"/>
    </div>
    {errors.telephone && (
                    <span className="telephone-error">{errors.telephone}</span>
                  )}
    </li>
<li>
    <button type="submit" className="button primary margin-20-top">Realizar compra</button>
</li>
 </div>
 <p>O también puedes entrar en contacto con nosotros por medio de Instagram o enviándo un mensaje de WhatsApp al +51 949-161-510.</p>
</form>
   )
}

export default CheckoutForm