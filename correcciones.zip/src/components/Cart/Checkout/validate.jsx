export default function validate(values) {
  let errors = {};
  if (!values.email) {
    errors.email = 'El e-mail es necesario';
  } else if (!/\S+@\S+\.\S+/.test(values.email)) {
    errors.email = 'El e-mail es necesario';
  }
  if (!values.telephone) {
    errors.telephone = 'El telefono es necesario';
  } else if (values.telephone.length < 8) {
    errors.telephone = 'El telefono debe ';
  } //incluir una línea para que solo acepte números entre 900,000,000 y 999,999,999
  return errors;
};