export default function DB (){
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve(order)
        },2000)
    })
}
const order = [
    {
        orderId: 1,
        buyer:{
            name: "Alberto",
            phone: "999 333 555",
            email: "juan@gmail.com" 
        },
        items:[{
            id:1,
            product:"Product-1",
            price: 20,
        }],
        total: 2, 
    },
    {

    },
    {

    },
]