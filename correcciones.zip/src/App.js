import './App.css';
import React, {useEffect, useState} from "react"
import NavBar from "./components/NavBar"
import Home from "./Containers/HomeContainer"
import ItemDetailContainer from "./components/ItemScreen/ItemDetailContainer"
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom"
import {AppProvider} from './Context/useAppContext';

import Cart from "./components/Cart/Cart"
import CategoryContainer from './Containers/CategoriesContainer';
import { getFirestore } from './firebase';

const NotFoundPage = () => {
  return <div className="no-items-div">
  <p>La URL que introdujiste es inválida.</p>
  <Link to="/" className="button primary">Volver al inicio</Link>
</div>
} 

function App() {
  return (
    <div>

  <AppProvider>
  <Router>
   <NavBar/>
    <Switch>
      <Route path="/productos/:category/:id">
        <ItemDetailContainer/>
      </Route>
      <Route path="/" exact component={Home}/>
      <Route path="/categoria/:cat" exact component={CategoryContainer}/>
      <Route path="/carrito" exact component={Cart}/>
      <Route component={NotFoundPage} />
      </Switch> 
      </Router>
  </AppProvider>
    </div>
  );
}


export default App;
